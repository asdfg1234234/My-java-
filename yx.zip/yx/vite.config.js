import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

// 使用相对 base，方便把 dist 直接丢到任意静态目录 / 本机预览
export default defineConfig({
  plugins: [vue()],
  base: './',
  server: {
    host: '127.0.0.1',
    port: 5173,
    // 把 /api 开头的请求转发到 Spring Boot 后端（默认 8081）。
    // 走代理后前后端同源，开发时完全不用处理跨域。
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:8081',
        changeOrigin: true
      }
    }
  }
})
