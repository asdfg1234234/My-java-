<script setup>
/**
 * 图片验证码（纯前端 canvas 实现）
 *
 * 用法：
 *   <ImageCaptcha ref="captchaRef" />
 *   // 提交时校验：if (!captchaRef.value.validate()) return
 *
 * 说明：验证码在前端本地生成、本地比对，只满足「填写图片验证码」的交互与演示效果，
 * 不具备真正的防刷能力（代码在浏览器里，无法阻止脚本绕过）。
 * 若要真正防机器注册，应把出图与校验挪到后端，参考现成的内存缓存写法
 * （com.fenglin.springboottest.service.SmsCodeService）：
 *   1. GET  /api/user/captcha  → 服务端用 BufferedImage 出图，返回 { captchaId, imageBase64 }
 *   2. POST /api/user/register → 带上 captchaId + captchaCode，服务端比对后一次性失效
 */
import { ref, onMounted } from 'vue'

const props = defineProps({
  /** 验证码字符个数 */
  length: { type: Number, default: 4 },
  /** 画布尺寸（CSS 像素） */
  width: { type: Number, default: 112 },
  height: { type: Number, default: 34 },
  /** 字段标题 */
  label: { type: String, default: '图片验证码' },
  /** 输入框占位文案 */
  placeholder: { type: String, default: '请输入右侧图片上的字符' },
  /** 字段下方的灰色提示 */
  hint: { type: String, default: '不区分大小写，看不清可点击图片换一张。' }
})

const emit = defineEmits(['change'])

const canvasRef = ref(null)
const input = ref('')
const err = ref('')

/** 当前正确答案（统一大写，比对时也转大写，所以不区分大小写） */
let answer = ''

/** 字符集：剔除 0/O、1/I/L 等易混字符，减少「明明看清了还是输错」 */
const CHARSET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
/** 字符配色：都是深色，保证在浅色底图上清晰可读 */
const INK = ['#2b3a67', '#6d28d9', '#0f766e', '#b91c1c', '#1d4ed8']

function randomChar() {
  return CHARSET[Math.floor(Math.random() * CHARSET.length)]
}

/** 把验证码画到 canvas 上：底纹 + 噪点 + 随机旋转/位移的字符 + 干扰线 */
function draw(code) {
  const canvas = canvasRef.value
  if (!canvas) return

  const ctx = canvas.getContext('2d')
  const w = props.width
  const h = props.height

  // 高清屏适配：按 devicePixelRatio 放大画布，再用 setTransform 回到 CSS 像素坐标系，
  // 否则文字边缘会发虚（canvas 默认按 1x 渲染）
  const dpr = window.devicePixelRatio || 1
  canvas.width = Math.round(w * dpr)
  canvas.height = Math.round(h * dpr)
  canvas.style.width = `${w}px`
  canvas.style.height = `${h}px`
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
  ctx.clearRect(0, 0, w, h)

  // 1. 渐变底色（与面板的浅色玻璃拟态风格保持一致）
  const bg = ctx.createLinearGradient(0, 0, w, h)
  bg.addColorStop(0, '#f4f7fd')
  bg.addColorStop(1, '#e8eefb')
  ctx.fillStyle = bg
  ctx.fillRect(0, 0, w, h)

  // 2. 背景干扰曲线
  for (let i = 0; i < 4; i++) {
    ctx.beginPath()
    ctx.moveTo(-6, Math.random() * h)
    ctx.bezierCurveTo(
      w * 0.3, Math.random() * h,
      w * 0.7, Math.random() * h,
      w + 6, Math.random() * h
    )
    ctx.strokeStyle = `rgba(${120 + Math.floor(Math.random() * 100)}, ${110 + Math.floor(Math.random() * 90)}, ${180 + Math.floor(Math.random() * 70)}, 0.45)`
    ctx.lineWidth = 1
    ctx.stroke()
  }

  // 3. 噪点
  for (let i = 0; i < 26; i++) {
    ctx.beginPath()
    ctx.arc(Math.random() * w, Math.random() * h, Math.random() * 1.1 + 0.3, 0, Math.PI * 2)
    ctx.fillStyle = `rgba(70, 80, 120, ${Math.random() * 0.35 + 0.12})`
    ctx.fill()
  }

  // 4. 字符：逐个随机纵向偏移 + 旋转 + 变色
  const gap = w / (code.length + 1)
  const fontSize = Math.round(h * 0.62)
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  for (let i = 0; i < code.length; i++) {
    const x = gap * (i + 1) + (Math.random() - 0.5) * 3
    const y = h / 2 + (Math.random() - 0.5) * (h * 0.16)
    ctx.save()
    ctx.translate(x, y)
    ctx.rotate((Math.random() - 0.5) * 0.6) // 约 ±17°
    ctx.font = `700 ${fontSize}px "PingFang SC", "Microsoft YaHei", "Segoe UI", sans-serif`
    ctx.fillStyle = INK[Math.floor(Math.random() * INK.length)]
    ctx.fillText(code[i], 0, 0)
    ctx.restore()
  }

  // 5. 压在字符上的前景细线，进一步增加识别难度
  for (let i = 0; i < 3; i++) {
    ctx.beginPath()
    ctx.moveTo(Math.random() * w, Math.random() * h)
    ctx.lineTo(Math.random() * w, Math.random() * h)
    ctx.strokeStyle = 'rgba(90, 100, 140, 0.28)'
    ctx.lineWidth = 1
    ctx.stroke()
  }
}

/** 重新生成一张验证码（清空输入与错误提示） */
function refresh() {
  let code = ''
  for (let i = 0; i < props.length; i++) {
    code += randomChar()
  }
  answer = code
  input.value = ''
  err.value = ''
  draw(code)
  emit('change', code)
}

/**
 * 校验用户输入，供父组件在提交时调用。
 *
 * @returns {boolean} true 表示填写正确
 */
function validate() {
  const value = input.value.trim().toUpperCase()
  let message = ''
  if (!value) {
    message = '请输入图片验证码'
  } else if (value !== answer) {
    message = '图片验证码错误'
  }

  if (!message) {
    err.value = ''
    return true
  }

  // 输错就换一张，避免被拿着同一张图反复试
  refresh()
  // refresh() 会清空 err，这里把提示补回来
  err.value = message
  return false
}

function onInput() {
  if (err.value) {
    err.value = ''
  }
}

onMounted(refresh)

defineExpose({ refresh, validate })
</script>

<template>
  <div class="field" :class="{ invalid: !!err }" id="fldCaptcha">
    <label>{{ label }}</label>
    <div class="control">
      <input
        v-model="input"
        type="text"
        :maxlength="length"
        :placeholder="placeholder"
        autocomplete="off"
        spellcheck="false"
        @input="onInput"
      />
      <button
        class="captcha-box"
        type="button"
        title="点击换一张"
        aria-label="刷新图片验证码"
        @click="refresh"
      >
        <canvas ref="canvasRef"></canvas>
      </button>
    </div>
    <div class="hint">{{ hint }}</div>
    <div class="error">{{ err }}</div>
  </div>
</template>
