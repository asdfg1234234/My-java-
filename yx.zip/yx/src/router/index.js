import { createRouter, createWebHashHistory } from 'vue-router'
import LoginView from '../views/LoginView.vue'
import RegisterView from '../views/RegisterView.vue'
import HomeView from '../views/HomeView.vue'

const routes = [
  // 根路径交给守卫决定：已登录进首页，未登录去登录页
  { path: '/', redirect: '/home' },
  { path: '/login', component: LoginView, meta: { public: true } },
  { path: '/register', component: RegisterView, meta: { public: true } },
  { path: '/home', component: HomeView }
]

const router = createRouter({
  // hash 模式：无需服务端配置，dist 直接静态托管 / 双击打开也能用
  history: createWebHashHistory(),
  routes
})

// 登录守卫：/home 需要登录态（game_token 由登录页写入 localStorage）
router.beforeEach((to) => {
  let logged = false
  try {
    logged = !!localStorage.getItem('game_token')
  } catch {
    // 隐私模式下 localStorage 可能不可用，按未登录处理
  }
  if (to.meta.public) {
    // 已登录再回登录/注册页没有意义，直接送去首页
    return logged ? '/home' : true
  }
  return logged ? true : '/login'
})

export default router
