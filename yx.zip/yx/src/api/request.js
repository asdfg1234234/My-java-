/**
 * 统一的请求封装（基于原生 fetch，无需额外依赖）。
 *
 * 约定：后端所有接口都返回 { code, message, data } 三段式结构，
 * code === 200 视为成功，否则把 message 当作错误信息抛出。
 *
 * 关于 baseURL：
 *  - 开发环境走 Vite 的 proxy（见 vite.config.js），'/api' 会被转发到后端 8081，
 *    此时 baseURL 留空即可（同源，无跨域问题）。
 *  - 如果需要直连后端，可以在项目根目录建 .env.local 写入：
 *      VITE_API_BASE_URL=http://127.0.0.1:8081
 */

const BASE_URL = import.meta.env.VITE_API_BASE_URL || ''

/** 业务成功的状态码 */
const CODE_SUCCESS = 200

function buildUrl(path, params) {
  let url = `${BASE_URL}${path}`
  if (params && Object.keys(params).length) {
    const qs = new URLSearchParams(
      Object.entries(params).filter(([, v]) => v !== undefined && v !== null)
    ).toString()
    if (qs) {
      url += (url.includes('?') ? '&' : '?') + qs
    }
  }
  return url
}

export async function request(path, { method = 'GET', body, params } = {}) {
  const options = {
    method,
    headers: {}
  }

  if (body !== undefined) {
    options.headers['Content-Type'] = 'application/json;charset=UTF-8'
    options.body = JSON.stringify(body)
  }

  let res
  try {
    res = await fetch(buildUrl(path, params), options)
  } catch (e) {
    // 网络层就失败了（后端没启动 / 端口不通 / 被浏览器拦截）
    throw new Error('无法连接服务器，请确认后端已启动（默认 http://127.0.0.1:8081）')
  }

  const text = await res.text()
  let payload = null
  if (text) {
    try {
      payload = JSON.parse(text)
    } catch (e) {
      // 后端返回了非 JSON（比如 404 的 HTML 错误页、或 500 的默认错误页）
      throw new Error(`服务器返回了非预期内容（HTTP ${res.status}）`)
    }
  }

  if (!payload || typeof payload.code === 'undefined') {
    throw new Error(`服务器响应格式异常（HTTP ${res.status}）`)
  }

  if (payload.code !== CODE_SUCCESS) {
    // 后端在 message 里给了可读的失败原因，直接透出给页面提示
    throw new Error(payload.message || `请求失败（code=${payload.code}）`)
  }

  return payload.data
}

export const http = {
  get: (path, params) => request(path, { method: 'GET', params }),
  post: (path, body) => request(path, { method: 'POST', body }),
  put: (path, body) => request(path, { method: 'PUT', body }),
  delete: (path, params) => request(path, { method: 'DELETE', params })
}
