/**
 * 用户模块接口
 * 对应后端 com.fenglin.springboottest.controller.UserApiController
 */
import { http } from './request'

/**
 * 提交注册（用户名 + 密码 + 二次确认密码）。
 *
 * 图片验证码在注册页本地（canvas）生成与比对，不参与请求；密码一致性也由页面先校验。
 * 后端 RegisterRequest 的字段与这里一一对应，注册成功会写入 MySQL 的 t_user 表。
 */
export function register({ username, password, confirmPassword }) {
  return http.post('/api/user/register', {
    username,
    password,
    confirmPassword
  })
}

/**
 * 登录。
 *
 * `account` 传用户名即可（后端兼容老数据的昵称）。
 */
export function login({ account, password }) {
  return http.post('/api/user/login', { account, password })
}

/**
 * 查询用户名是否已被占用。
 *
 * 注册页目前只做本地格式校验，如果要做「边输入边提示是否重名」，
 * 在这里做一次防抖调用即可：const { registered } = await checkUsername(name)
 */
export function checkUsername(username) {
  return http.get('/api/user/check-username', { username })
}
