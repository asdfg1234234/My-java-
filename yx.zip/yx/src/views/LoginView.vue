<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useToast } from '../composables/useToast'
import { login as apiLogin } from '../api/user'

const { show: toast } = useToast()
const router = useRouter()

const username = ref('')
const pwd = ref('')
// 登录请求进行中
const loading = ref(false)

async function onUserLogin(e) {
  e.preventDefault()
  if (!username.value.trim()) {
    toast('请输入用户名')
    return
  }
  if (!pwd.value) {
    toast('请输入密码')
    return
  }
  if (pwd.value.length < 6) {
    toast('密码长度至少 6 位')
    return
  }

  loading.value = true
  try {
    // 真正请求后端校验用户名密码（account 即用户名）
    const data = await apiLogin({ account: username.value.trim(), password: pwd.value })
    toast('登录成功，正在进入游戏…')

    // 演示用：把登录态存到 localStorage，刷新页面后还能恢复
    try {
      localStorage.setItem('game_token', (data && data.token) || '')
      localStorage.setItem('game_user', JSON.stringify((data && data.user) || {}))
    } catch (storageErr) {
      // 隐私模式下 localStorage 可能不可用，忽略即可
    }

    // 稍作停留让 toast 能看到，然后进入游戏首页
    setTimeout(() => router.push('/home'), 900)
  } catch (err) {
    toast(err.message, 4000)
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div class="screen">
    <div class="panel">
      <div class="brand">
        <div class="logo">幻</div>
        <div>
          <h1>幻境启元</h1>
          <div class="sub">ENTER THE FANTASY REALM</div>
        </div>
      </div>

      <div class="title">
        登录你的游戏账号
        <small>输入用户名和密码即可登录</small>
      </div>

      <form id="loginForm" novalidate @submit="onUserLogin">
        <div class="field">
          <div class="control">
            <span class="ico-mini" aria-hidden="true">
              <svg viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm0 2c-4 0-8 2-8 5v1h16v-1c0-3-4-5-8-5z" />
              </svg>
            </span>
            <input v-model="username" type="text" placeholder="请输入用户名" autocomplete="username" spellcheck="false" />
          </div>
        </div>

        <div class="field">
          <div class="control">
            <span class="ico-mini" aria-hidden="true">
              <svg viewBox="0 0 24 24" fill="currentColor">
                <path d="M17 9V7a5 5 0 0 0-10 0v2H5v13h14V9h-2zM9 7a3 3 0 0 1 6 0v2H9V7zm4 11h-2v-4h2v4z" />
              </svg>
            </span>
            <input v-model="pwd" type="password" placeholder="密码" autocomplete="current-password" />
          </div>
        </div>

        <button class="btn btn-primary" type="submit" style="width: 100%" :disabled="loading">
          {{ loading ? '登录中…' : '登 录' }}
        </button>
      </form>

      <div class="divider"><span>其他登录方式</span></div>

      <!-- QQ / 微信入口（演示态，点击只给提示） -->
      <div class="icon-row">
        <button class="icon-btn icon-qq" type="button" title="QQ登录" aria-label="QQ登录" @click="toast('正在调起 QQ 授权登录…')">
          <svg viewBox="0 0 24 24">
            <ellipse cx="12" cy="12.5" rx="6.6" ry="7.6" fill="#fff" />
            <ellipse cx="12" cy="14" rx="3.9" ry="4.9" fill="#0a3d6b" />
            <circle cx="9.3" cy="9.4" r="1.15" fill="#0a3d6b" />
            <circle cx="14.7" cy="9.4" r="1.15" fill="#0a3d6b" />
            <path d="M11 11.2 12.2 12.9 13.4 11.2Z" fill="#ff9f1c" />
          </svg>
        </button>
        <button class="icon-btn icon-wechat" type="button" title="微信登录" aria-label="微信登录" @click="toast('正在调起微信授权登录…')">
          <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M9 3C4.9 3 1.6 5.8 1.6 9.1c0 1.9 1 3.6 2.7 4.7L3.1 16l2.6-1.4c.9.3 1.9.5 2.9.5h.5c-.3-.6-.5-1.3-.5-2 0-3 2.9-5.2 6.4-5.2h.3C14.8 5 12.2 3 9 3z" />
            <circle cx="6.4" cy="9" r="1" />
            <circle cx="11.4" cy="9" r="1" />
            <path d="M22.4 14.2c0-2.6-2.6-4.7-5.8-4.7s-5.8 2.1-5.8 4.7 2.6 4.7 5.8 4.7c.7 0 1.4-.1 2-.3l1.9 1-.5-1.6c1.5-.9 2.4-2.2 2.4-3.8z" />
            <circle cx="14.8" cy="14.1" r=".8" />
            <circle cx="18.6" cy="14.1" r=".8" />
          </svg>
        </button>
      </div>

      <div class="register-hint">
        还没有账号？<router-link to="/register">立即注册</router-link>
      </div>
    </div>
  </div>
</template>
