<script setup>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'
import { useToast } from '../composables/useToast'

const { show: toast } = useToast()
const router = useRouter()

/* ---------- 玩家信息（来自登录接口，落在 localStorage） ---------- */
function readUser() {
  try {
    return JSON.parse(localStorage.getItem('game_user')) || {}
  } catch {
    return {}
  }
}
const user = readUser()
const nickname = computed(() => user.nickname || user.username || '无名旅者')
const avatarChar = computed(() => nickname.value.slice(0, 1).toUpperCase())

/* 演示数据：等级 / 经验 / 货币（后端暂无对应接口，先静态展示） */
const level = ref(3)
const expCur = ref(30)
const expMax = ref(400)
const gold = ref(7500)
const gem = ref(0)
const stamina = ref(120)
const staminaMax = ref(120)
const expPct = computed(() => `${Math.min(100, (expCur.value / expMax.value) * 100)}%`)

/* ---------- 公告跑马灯 ---------- */
const notices = [
  '新版本「幻境秘境」已开启：全新秘境玩法与限定奖励等你探索！',
  '每周日 20:00 竞技场赛季结算，段位奖励记得领取哦～',
  '新手七日签到已上线，连续登录领取专属坐骑「星尘鹿」！'
]
const noticeIdx = ref(0)
setInterval(() => {
  noticeIdx.value = (noticeIdx.value + 1) % notices.length
}, 5000)

/* ---------- 交互 ---------- */
function coming(name) {
  toast(`「${name}」功能开发中，敬请期待`)
}
function startAdventure() {
  toast('正在进入秘境探索…（演示：玩法接口尚未接入）')
}
function addCurrency(name) {
  toast(`跳转${name}充值（演示入口）`)
}
function logout() {
  try {
    localStorage.removeItem('game_token')
    localStorage.removeItem('game_user')
  } catch {
    /* 忽略隐私模式下的存储异常 */
  }
  toast('已退出登录')
  setTimeout(() => router.push('/login'), 600)
}
</script>

<template>
  <div class="home">
    <!-- ═══════════ 顶部 HUD：玩家信息 / 货币 / 功能入口 ═══════════ -->
    <header class="hud-top">
      <!-- 玩家卡片 -->
      <div class="glass player-card">
        <div class="avatar-wrap">
          <div class="avatar">{{ avatarChar }}</div>
          <span class="lv-badge">Lv.{{ level }}</span>
        </div>
        <div class="pinfo">
          <div class="pname">{{ nickname }}</div>
          <div class="exp-row">
            <div class="exp-track"><i :style="{ width: expPct }"></i></div>
            <span class="exp-num">{{ expCur }}/{{ expMax }}</span>
          </div>
        </div>
      </div>

      <!-- 货币栏 -->
      <div class="glass currency">
        <div class="chip">
          <span class="coin-ico gold">
            <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" fill="url(#gGold)" stroke="#a16207" stroke-width="1.6" /><path d="m12 6.2 1.6 3.4 3.7.5-2.7 2.6.7 3.7-3.3-1.8-3.3 1.8.7-3.7-2.7-2.6 3.7-.5Z" fill="#b45309" /></svg>
          </span>
          <b>{{ gold }}</b>
          <button class="plus" title="充值金币" @click="addCurrency('金币')">+</button>
        </div>
        <div class="chip">
          <span class="coin-ico gem">
            <svg viewBox="0 0 24 24"><path d="M12 2.5 20 9l-8 12L4 9Z" fill="url(#gGem)" stroke="#6d28d9" stroke-width="1.4" /></svg>
          </span>
          <b>{{ gem }}</b>
          <button class="plus" title="充值梦晶" @click="addCurrency('梦晶')">+</button>
        </div>
        <div class="chip">
          <span class="coin-ico bolt">
            <svg viewBox="0 0 24 24"><path d="M13 2 5 13.5h5L9.5 22 19 9.5h-5.5Z" fill="#f59e0b" stroke="#b45309" stroke-width="1.2" /></svg>
          </span>
          <b>{{ stamina }}/{{ staminaMax }}</b>
        </div>
      </div>

      <!-- 右上功能按钮 -->
      <div class="glass top-actions">
        <button class="hbtn" title="邮件" @click="coming('邮件')">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="5" width="18" height="14" rx="2.5" /><path d="m4 7 8 6 8-6" /></svg>
          <i class="dot"></i>
        </button>
        <button class="hbtn" title="好友" @click="coming('好友')">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="9" cy="8.5" r="3.4" /><path d="M3.5 19c.6-3.2 2.8-5 5.5-5s4.9 1.8 5.5 5" /><path d="M17 8h5M19.5 5.5v5" /></svg>
        </button>
        <button class="hbtn" title="设置" @click="coming('设置')">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="3.2" /><path d="M12 2.8v3M12 18.2v3M2.8 12h3M18.2 12h3M5.5 5.5l2.1 2.1M16.4 16.4l2.1 2.1M18.5 5.5l-2.1 2.1M7.6 16.4l-2.1 2.1" /></svg>
        </button>
        <button class="hbtn exit" title="退出登录" @click="logout">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M14 4H6v16h8" /><path d="M11 12h9m-3.2-3.4L20.2 12l-3.4 3.4" /></svg>
        </button>
      </div>
    </header>

    <!-- ═══════════ 中部：两侧功能栏 + 中央主视觉 ═══════════ -->
    <div class="mid">
      <!-- 公告跑马灯 -->
      <div class="glass notice">
        <span class="n-tag">公告</span>
        <transition name="slide-notice" mode="out-in">
          <p :key="noticeIdx" class="n-text">{{ notices[noticeIdx] }}</p>
        </transition>
      </div>

      <!-- 左侧竖栏 -->
      <aside class="rail rail-left">
        <button class="glass rail-btn" @click="coming('好友列表')">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="9" cy="8.5" r="3.4" /><path d="M3.5 19c.6-3.2 2.8-5 5.5-5s4.9 1.8 5.5 5" /><path d="M17 8h5M19.5 5.5v5" /></svg>
          <span>好友</span>
        </button>
        <button class="glass rail-btn" @click="coming('排行榜')">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 20V10M12 20V4M19 20v-7" /><path d="M2.5 20h19" /></svg>
          <span>排行</span>
        </button>
        <button class="glass rail-btn" @click="coming('公会')">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m12 2.8 8 3.4v5.3c0 5-3.4 8.4-8 9.7-4.6-1.3-8-4.7-8-9.7V6.2Z" /><path d="m8.8 12 2.2 2.2 4.2-4.4" /></svg>
          <span>公会</span>
        </button>
      </aside>

      <!-- 中央主视觉 -->
      <main class="hero">
        <h1 class="game-title">幻境启元</h1>
        <p class="game-sub">ENTER THE FANTASY REALM</p>

        <div class="mode-row">
          <button class="mode glass side" @click="coming('竞技场')">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M6.5 3.5v6a5.5 5.5 0 0 0 11 0v-6" /><path d="M6.5 6.5H3.2M20.8 6.5h-3.3M12 15v5.5M8.5 20.5h7" /></svg>
            <b>竞技场</b>
            <small>赛季进行中</small>
          </button>

          <button class="mode main" @click="startAdventure">
            <i class="ring" aria-hidden="true"></i>
            <svg class="m-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><path d="M12 2.8c2 3.4 5.4 5.2 5.4 9.2A5.4 5.4 0 0 1 12 17.4a5.4 5.4 0 0 1-5.4-5.4c0-4 3.4-5.8 5.4-9.2Z" /><path d="M12 17.4V21.2" /></svg>
            <b>开始冒险</b>
            <small>秘境探索 · 即刻出发</small>
          </button>

          <button class="mode glass side" @click="coming('排位试炼')">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 15 3 21h18l-2-6" /><path d="M8.5 15a7 7 0 1 1 7 0" /><circle cx="12" cy="8.6" r="2.4" /></svg>
            <b>排位试炼</b>
            <small>6 段位解锁</small>
          </button>
        </div>
      </main>

      <!-- 右侧竖栏 -->
      <aside class="rail rail-right">
        <button class="glass event-card" @click="coming('限时活动')">
          <b>幻境秘宝</b>
          <span>限时活动 · 剩余 3 天</span>
        </button>
        <button class="glass event-card warm" @click="coming('每日签到')">
          <b>七日签到</b>
          <span>今日可领 星尘鹿</span>
          <i class="dot"></i>
        </button>
        <button class="glass rail-btn" @click="coming('战令')">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20 7.5 12 3 4 7.5v9L12 21l8-4.5Z" /><path d="m8.4 12.2 2.4 2.4 4.8-5" /></svg>
          <span>战令</span>
        </button>
      </aside>
    </div>

    <!-- ═══════════ 底部页签 ═══════════ -->
    <nav class="glass tabbar">
      <button class="tab" @click="coming('英雄')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3.5 14.3 9l5.9.4-4.5 3.9 1.4 5.7L12 15.9l-5.1 3.1 1.4-5.7-4.5-3.9L9.7 9Z" /></svg>
        <span>英雄</span>
      </button>
      <button class="tab" @click="coming('背包')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="4" y="8" width="16" height="12" rx="2.5" /><path d="M8.5 8V6.2a3.5 3.5 0 0 1 7 0V8" /></svg>
        <span>背包</span>
      </button>
      <button class="tab" @click="coming('任务')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="5" y="4" width="14" height="17" rx="2.5" /><path d="M9 4.2V3h6v1.2M8.6 11h6.8M8.6 15h4.4" /></svg>
        <span>任务</span>
        <i class="dot new"></i>
      </button>
      <button class="tab" @click="coming('天赋')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="6" r="2.6" /><circle cx="6" cy="17" r="2.6" /><circle cx="18" cy="17" r="2.6" /><path d="M12 8.6v3.2m0 0-4.2 3.4M12 11.8l4.2 3.4" /></svg>
        <span>天赋</span>
      </button>
      <button class="tab" @click="coming('商城')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4.5 8h15l-1.2 12h-12.6Z" /><path d="M8.5 10.5V7a3.5 3.5 0 0 1 7 0v3.5" /></svg>
        <span>商城</span>
      </button>
    </nav>

    <!-- SVG 渐变定义（货币图标用） -->
    <svg width="0" height="0" style="position:absolute" aria-hidden="true">
      <defs>
        <linearGradient id="gGold" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stop-color="#fde68a" /><stop offset="1" stop-color="#f59e0b" />
        </linearGradient>
        <linearGradient id="gGem" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stop-color="#c4b5fd" /><stop offset="1" stop-color="#8b5cf6" />
        </linearGradient>
      </defs>
    </svg>
  </div>
</template>

<style scoped>
/* =========================================================
   游戏首页 · 大厅 HUD
   沿用登录页视觉：海报背景 + 玻璃拟态 + 青→紫渐变点缀
   布局参考 MOBA 大厅（顶部信息/两侧功能/中央模式/底部页签）
   ========================================================= */

.home {
  position: relative;
  z-index: 1;
  height: 100vh;
  display: flex;
  flex-direction: column;
  padding: 14px 16px;
  color: var(--text);
}

/* 玻璃底座（与登录页 panel 同一质感） */
.glass {
  background: rgba(255, 255, 255, 0.52);
  border: 1px solid rgba(255, 255, 255, 0.72);
  border-radius: 14px;
  backdrop-filter: blur(18px) saturate(1.15);
  -webkit-backdrop-filter: blur(18px) saturate(1.15);
  box-shadow: 0 10px 34px rgba(31, 41, 70, 0.14), inset 0 1px 0 rgba(255, 255, 255, 0.75);
}

button.glass { cursor: pointer; transition: transform .15s ease, box-shadow .2s ease, filter .2s ease; }
button.glass:hover { transform: translateY(-2px); filter: brightness(1.04); box-shadow: 0 14px 40px rgba(31, 41, 70, 0.2); }
button.glass:active { transform: translateY(0) scale(.97); }

/* ---------- 顶部 HUD ---------- */
.hud-top {
  display: flex;
  align-items: center;
  gap: 12px;
  flex: none;
}

.player-card {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 16px 8px 8px;
}
.avatar-wrap { position: relative; flex: none; }
.avatar {
  width: 46px; height: 46px;
  border-radius: 50%;
  background: linear-gradient(135deg, var(--cyan), var(--violet));
  color: #fff;
  display: grid; place-items: center;
  font-size: 20px; font-weight: 800;
  box-shadow: 0 0 0 2px rgba(255,255,255,.85), 0 4px 14px rgba(124,92,255,.45);
}
.lv-badge {
  position: absolute;
  right: -8px; bottom: -6px;
  padding: 1px 7px;
  border-radius: 9px;
  font-size: 10px; font-weight: 700;
  color: #fff;
  background: linear-gradient(135deg, #f59e0b, #ef6c2e);
  box-shadow: 0 2px 8px rgba(239,108,46,.45);
}
.pname { font-size: 14px; font-weight: 700; letter-spacing: .4px; }
.exp-row { display: flex; align-items: center; gap: 8px; margin-top: 5px; }
.exp-track {
  width: 120px; height: 7px;
  border-radius: 4px;
  background: rgba(20, 30, 60, .14);
  overflow: hidden;
}
.exp-track i {
  display: block; height: 100%;
  border-radius: 4px;
  background: linear-gradient(90deg, var(--cyan), var(--violet));
  box-shadow: 0 0 8px rgba(139, 92, 246, .6);
}
.exp-num { font-size: 11px; color: var(--text-dim); }

.currency {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 8px 10px;
}
.chip { display: flex; align-items: center; gap: 7px; padding: 0 8px; }
.chip b { font-size: 13.5px; letter-spacing: .3px; min-width: 34px; }
.chip + .chip { border-left: 1px solid rgba(20, 30, 60, .1); }
.coin-ico { width: 21px; height: 21px; display: grid; place-items: center; flex: none; }
.coin-ico svg { width: 21px; height: 21px; }
.plus {
  width: 17px; height: 17px;
  border: none; border-radius: 50%;
  background: linear-gradient(135deg, var(--cyan), var(--violet));
  color: #fff; font-size: 12px; font-weight: 700; line-height: 1;
  cursor: pointer;
  display: grid; place-items: center;
  transition: filter .15s, transform .15s;
}
.plus:hover { filter: brightness(1.15); transform: scale(1.1); }

.top-actions { display: flex; align-items: center; gap: 4px; padding: 7px 10px; margin-left: auto; }
.hbtn {
  position: relative;
  width: 38px; height: 38px;
  border: none; border-radius: 10px;
  background: transparent;
  color: var(--text-dim);
  cursor: pointer;
  display: grid; place-items: center;
  transition: background .15s, color .15s, transform .15s;
}
.hbtn svg { width: 20px; height: 20px; }
.hbtn:hover { background: rgba(139, 92, 246, .12); color: var(--violet); transform: translateY(-1px); }
.hbtn.exit:hover { background: rgba(226, 58, 94, .12); color: var(--danger); }
.dot {
  position: absolute;
  top: 7px; right: 8px;
  width: 7px; height: 7px;
  border-radius: 50%;
  background: var(--danger);
  box-shadow: 0 0 0 2px rgba(255, 255, 255, .8);
}

/* ---------- 中部 ---------- */
.mid { position: relative; flex: 1; min-height: 0; }

/* 公告跑马灯 */
.notice {
  position: absolute;
  top: 10px; left: 0;
  display: flex;
  align-items: center;
  gap: 10px;
  max-width: min(520px, 60vw);
  padding: 7px 16px 7px 8px;
  overflow: hidden;
}
.n-tag {
  flex: none;
  padding: 2px 10px;
  border-radius: 8px;
  font-size: 11px; font-weight: 700;
  color: #fff;
  background: linear-gradient(135deg, var(--cyan), var(--violet));
}
.n-text {
  font-size: 12.5px;
  color: var(--text);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.slide-notice-enter-active, .slide-notice-leave-active { transition: opacity .4s, transform .4s; }
.slide-notice-enter-from { opacity: 0; transform: translateX(18px); }
.slide-notice-leave-to { opacity: 0; transform: translateX(-18px); }

/* 两侧竖栏 */
.rail {
  position: absolute;
  top: 58px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  z-index: 2;
}
.rail-left { left: 0; }
.rail-right { right: 0; }

.rail-btn {
  width: 62px;
  padding: 10px 0 8px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  border: 1px solid rgba(255, 255, 255, 0.72);
  color: var(--text);
}
.rail-btn svg { width: 21px; height: 21px; color: var(--violet); }
.rail-btn span { font-size: 11.5px; font-weight: 600; letter-spacing: 1px; }

.event-card {
  position: relative;
  width: 118px;
  padding: 10px 12px;
  text-align: left;
  border: 1px solid rgba(255, 255, 255, 0.72);
  background: linear-gradient(135deg, rgba(43, 179, 200, .34), rgba(139, 92, 246, .34)), rgba(255, 255, 255, .52);
}
.event-card.warm { background: linear-gradient(135deg, rgba(245, 158, 11, .3), rgba(226, 58, 94, .28)), rgba(255, 255, 255, .52); }
.event-card b { display: block; font-size: 13px; letter-spacing: .5px; }
.event-card span { display: block; margin-top: 3px; font-size: 10.5px; color: var(--text-dim); }
.event-card .dot { top: 9px; right: 10px; }

/* 中央主视觉 */
.hero {
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding-bottom: 8px;
}
.game-title {
  font-size: clamp(34px, 5.4vw, 58px);
  font-weight: 900;
  letter-spacing: 10px;
  text-indent: 10px;
  background: linear-gradient(180deg, #2b3a55 20%, #5b4a9e 70%, #2bb3c8 110%);
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
  filter: drop-shadow(0 6px 22px rgba(91, 74, 158, .35));
}
.game-sub {
  margin-top: 8px;
  font-size: 12px;
  letter-spacing: 6px;
  text-indent: 6px;
  color: var(--text-dim);
}

.mode-row {
  display: flex;
  align-items: stretch;
  gap: 14px;
  margin-top: clamp(20px, 4.5vh, 44px);
}
.mode {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  border: none;
  cursor: pointer;
  color: #fff;
  transition: transform .15s ease, box-shadow .2s ease, filter .2s ease;
}
.mode:hover { transform: translateY(-3px); filter: brightness(1.06); }
.mode:active { transform: translateY(0) scale(.97); }

/* 两侧小模式 */
.mode.side {
  width: 132px;
  padding: 16px 10px 13px;
  border-radius: 16px;
  background: rgba(255, 255, 255, 0.55);
  border: 1px solid rgba(255, 255, 255, 0.72);
  backdrop-filter: blur(18px) saturate(1.15);
  box-shadow: 0 10px 34px rgba(31, 41, 70, 0.14);
  color: var(--text);
  align-self: center;
}
.mode.side svg { width: 24px; height: 24px; color: var(--violet); }
.mode.side b { font-size: 15px; letter-spacing: 2px; }
.mode.side small { font-size: 10.5px; color: var(--text-dim); }

/* 中央主模式：发光圆环 + 大按钮 */
.mode.main {
  position: relative;
  width: 190px;
  height: 190px;
  border-radius: 50%;
  background: linear-gradient(145deg, var(--cyan) 0%, #6d5ae0 58%, var(--violet) 100%);
  box-shadow: 0 18px 50px rgba(109, 90, 224, .5), inset 0 2px 0 rgba(255, 255, 255, .5);
  animation: mainBreath 3.2s ease-in-out infinite;
}
.mode.main b { font-size: 21px; letter-spacing: 5px; text-indent: 5px; text-shadow: 0 2px 8px rgba(30, 20, 80, .4); }
.mode.main small { font-size: 10.5px; opacity: .85; }
.mode.main .m-ico { width: 30px; height: 30px; }
.mode.main .ring {
  position: absolute;
  inset: -9px;
  border-radius: 50%;
  border: 2px solid rgba(139, 92, 246, .55);
  border-top-color: rgba(43, 179, 200, .9);
  animation: ringSpin 5s linear infinite;
}
.mode.main .ring::after {
  content: "";
  position: absolute;
  inset: -7px;
  border-radius: 50%;
  border: 1px dashed rgba(139, 92, 246, .35);
  animation: ringSpin 9s linear infinite reverse;
}
@keyframes mainBreath {
  0%, 100% { box-shadow: 0 18px 50px rgba(109, 90, 224, .5), inset 0 2px 0 rgba(255, 255, 255, .5); }
  50% { box-shadow: 0 18px 64px rgba(109, 90, 224, .72), inset 0 2px 0 rgba(255, 255, 255, .5); }
}
@keyframes ringSpin { to { transform: rotate(360deg); } }

/* ---------- 底部页签 ---------- */
.tabbar {
  flex: none;
  display: flex;
  justify-content: center;
  gap: clamp(6px, 3vw, 34px);
  padding: 8px 18px;
}
.tab {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 3px;
  padding: 5px 16px;
  border: none;
  border-radius: 12px;
  background: transparent;
  color: var(--text);
  cursor: pointer;
  transition: background .15s, transform .15s;
}
.tab:hover { background: rgba(139, 92, 246, .12); transform: translateY(-2px); }
.tab svg { width: 21px; height: 21px; color: var(--violet); }
.tab span { font-size: 12px; font-weight: 600; letter-spacing: 2px; }
.dot.new { top: 3px; right: 8px; }

/* ---------- 小屏适配 ---------- */
@media (max-width: 900px) {
  .rail-right { display: none; }
  .rail-left { top: auto; bottom: 8px; flex-direction: row; }
  .rail-btn { width: auto; padding: 8px 14px; flex-direction: row; gap: 6px; }
  .notice { max-width: 86vw; }
  .mode.side { display: none; }
  .currency { display: none; }
}
</style>
