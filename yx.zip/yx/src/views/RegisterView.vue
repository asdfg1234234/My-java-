<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useToast } from '../composables/useToast'
import ImageCaptcha from '../components/ImageCaptcha.vue'
// 注册相关的后端接口
import { register as apiRegister } from '../api/user'

const { show: toast } = useToast()
const router = useRouter()

const username = ref('')
const pwd = ref('')
const pwd2 = ref('')

// 图片验证码组件：生成与比对都在组件内部完成，这里只拿它的引用调 validate()
const captchaRef = ref(null)

// 每个字段的状态：'' / 'valid' / 'invalid' + 错误文案
const usernameState = ref('')
const usernameErr = ref('')
const pwdState = ref('')
const pwdErr = ref('')
const pwd2State = ref('')
const pwd2Err = ref('')

const strengthLevel = ref(0)
const submitting = ref(false)

/**
 * 用户名规则：4—20 位，字母开头，只能包含字母、数字和下划线。
 * 首字符限定为字母，可以避免「纯数字用户名」和手机号、ID 混淆。
 */
const USERNAME_PATTERN = /^[A-Za-z][A-Za-z0-9_]{3,19}$/

function usernameErrors(v) {
  if (!v) return ['请输入用户名']
  if (!USERNAME_PATTERN.test(v)) {
    return ['用户名需 4—20 位，以字母开头，只能包含字母、数字和下划线']
  }
  return []
}

// 密码规则：6—15位，含大写 + 小写 + 数字，不允许空格
function passwordErrors(v) {
  const errs = []
  if (!v) return ['请输入密码']
  if (v.length < 6 || v.length > 15) errs.push('密码长度需为6—15位')
  if (/\s/.test(v)) errs.push('密码不能包含空格')
  const hasUp = /[A-Z]/.test(v)
  const hasLow = /[a-z]/.test(v)
  const hasNum = /\d/.test(v)
  if (!hasUp || !hasLow || !hasNum) errs.push('密码必须包含大写字母、小写字母和数字')
  return errs
}

function strength(v) {
  if (!v) return 0
  let s = 0
  if (v.length >= 6 && v.length <= 15) s++
  if (/[A-Z]/.test(v) && /[a-z]/.test(v) && /\d/.test(v)) s++
  if (s === 2 && !/\s/.test(v)) s++
  return s
}

function onUsernameInput() {
  const v = username.value.trim()
  if (!v) {
    usernameState.value = ''
    usernameErr.value = ''
    return
  }
  const errs = usernameErrors(v)
  if (errs.length) {
    usernameState.value = 'invalid'
    usernameErr.value = errs[0]
  } else {
    usernameState.value = 'valid'
    usernameErr.value = ''
  }
}

function onPwdInput() {
  strengthLevel.value = strength(pwd.value)
  if (!pwd.value) {
    pwdState.value = ''
    pwdErr.value = ''
    return
  }
  const errs = passwordErrors(pwd.value)
  if (errs.length) {
    pwdState.value = 'invalid'
    pwdErr.value = errs[0]
  } else {
    pwdState.value = 'valid'
    pwdErr.value = ''
  }
  // 密码变化时同步校验确认密码
  if (pwd2.value) onPwd2Input()
}

function onPwd2Input() {
  if (!pwd2.value) {
    pwd2State.value = ''
    pwd2Err.value = ''
    return
  }
  if (pwd2.value !== pwd.value) {
    pwd2State.value = 'invalid'
    pwd2Err.value = '两次输入的密码不一致'
  } else {
    pwd2State.value = 'valid'
    pwd2Err.value = ''
  }
}

async function onSubmit(e) {
  e.preventDefault()
  let ok = true

  const uerrs = usernameErrors(username.value.trim())
  if (uerrs.length) {
    usernameState.value = 'invalid'
    usernameErr.value = uerrs[0]
    ok = false
  } else {
    usernameState.value = 'valid'
    usernameErr.value = ''
  }

  const perrs = passwordErrors(pwd.value)
  if (perrs.length) {
    pwdState.value = 'invalid'
    pwdErr.value = perrs[0]
    ok = false
  } else {
    pwdState.value = 'valid'
    pwdErr.value = ''
  }

  if (pwd2.value !== pwd.value) {
    pwd2State.value = 'invalid'
    pwd2Err.value = '两次输入的密码不一致'
    ok = false
  } else if (pwd2.value) {
    pwd2State.value = 'valid'
    pwd2Err.value = ''
  }

  // 图片验证码：本地比对，失败时组件自己会换一张并给出提示
  if (captchaRef.value && !captchaRef.value.validate()) {
    ok = false
  }

  if (!ok) {
    toast('请检查表单填写')
    return
  }

  submitting.value = true
  try {
    // 真正把注册数据提交给 Spring Boot 后端，由后端写入 MySQL 的 t_user 表
    const user = await apiRegister({
      username: username.value.trim(),
      password: pwd.value,
      confirmPassword: pwd2.value
    })

    const name = (user && (user.nickname || user.username)) || ''
    toast(`注册成功${name ? '，' + name : ''}，即将跳转登录页`)
    setTimeout(() => {
      router.push('/login')
    }, 1100)
    // 成功后不重置 submitting，保持按钮禁用，避免用户重复点击造成重复提交
  } catch (err) {
    submitting.value = false
    toast(err.message, 4000)

    // 验证码答错，立刻换一张，方便用户重试
    if (/验证码/.test(err.message) && captchaRef.value) {
      captchaRef.value.refresh()
    }

    // 尽量把后端返回的错误定位到具体字段，方便用户直接修改
    if (/用户名/.test(err.message)) {
      usernameState.value = 'invalid'
      usernameErr.value = err.message
    } else if (/密码/.test(err.message)) {
      pwdState.value = 'invalid'
      pwdErr.value = err.message
    }
  }
}
</script>

<template>
  <div class="screen">
    <div class="panel">
      <div class="brand">
        <div class="logo">幻</div>
        <div>
          <h1>创建账号</h1>
          <div class="sub">JOIN THE FANTASY REALM</div>
        </div>
      </div>

      <div class="title">
        注册你的游戏账号
        <small>设置用户名和密码，填对图片验证码即可创建</small>
      </div>

      <form id="registerForm" novalidate @submit="onSubmit">
        <div class="field" :class="usernameState" id="fldUsername">
          <label>用户名</label>
          <div class="control">
            <input
              v-model="username"
              type="text"
              maxlength="20"
              placeholder="请输入用户名"
              autocomplete="username"
              spellcheck="false"
              @input="onUsernameInput"
            />
          </div>
          <div class="hint">4—20 位，以字母开头，只能包含字母、数字和下划线。</div>
          <div class="error">{{ usernameErr }}</div>
        </div>

        <div class="field" :class="pwdState" id="fldPwd">
          <label>密码</label>
          <div class="control">
            <input v-model="pwd" type="password" maxlength="15" placeholder="请设置登录密码" autocomplete="new-password" @input="onPwdInput" />
          </div>
          <div class="hint">密码需为6—15位，且同时包含大写字母、小写字母和数字。</div>
          <div class="password-meter">
            <i v-for="i in 3" :key="i" :class="strengthLevel >= i ? 'on' + strengthLevel : ''"></i>
          </div>
          <div class="error">{{ pwdErr }}</div>
        </div>

        <div class="field" :class="pwd2State" id="fldPwd2">
          <label>确认密码</label>
          <div class="control">
            <input v-model="pwd2" type="password" maxlength="15" placeholder="请再次输入密码" autocomplete="new-password" @input="onPwd2Input" />
          </div>
          <div class="error">{{ pwd2Err }}</div>
        </div>

        <ImageCaptcha ref="captchaRef" />

        <button class="btn btn-primary" type="submit" style="width: 100%; margin-top: 6px" :disabled="submitting">
          {{ submitting ? '注册中…' : '注 册' }}
        </button>
      </form>

      <div class="inline-link">
        已有账号？<router-link to="/login">去登录</router-link>
      </div>
    </div>
  </div>
</template>
